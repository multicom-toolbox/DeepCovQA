t: 10 models with context 5 in training
e: 10 models with context 0 in training
